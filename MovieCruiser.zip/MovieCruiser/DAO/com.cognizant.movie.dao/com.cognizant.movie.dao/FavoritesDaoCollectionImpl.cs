﻿using System;
using System.Collections.Generic;
using com.cognizant.movie.model;
using com.cognizant.movie.util;

namespace com.cognizant.movie.dao {
   public class FavoritesDaoCollectionImpl : IFavoritesDao {
        private static Dictionary<long, Favorites> _userFavorites;
        public FavoritesDaoCollectionImpl() {
            if (_userFavorites == null) {
                _userFavorites = new Dictionary<long, Favorites>();
            }
        }
        public void addFavorite(long userId, long favoriteId) {
            MovieDaoCollectionImpl movieDao = new MovieDaoCollectionImpl();
            Movie movie = movieDao.getMovie(favoriteId);
            if (_userFavorites.ContainsKey(userId)) {
                _userFavorites[userId].MovieList.Add(movie);
            }
          
            else {
                Favorites newFavorites = new Favorites();
                List<Movie> movies = new List<Movie>();
                movies.Add(movie);
                newFavorites.MovieList =movies;
                _userFavorites.Add(userId, newFavorites);
            }
        }

        public Favorites getAllFavorites(long userId) {

            Favorites favorites = new Favorites();
            bool check = _userFavorites.TryGetValue(userId, out favorites);
           if (favorites == null || favorites.MovieList.Count == 0) {
                throw new FavoriteEmptyException("Exception:No item in the Favorites");
            }
            if (check) {               
                List<Movie> movieList = favorites.MovieList;
                double totalPrice = 0;      
                foreach (Movie movie in movieList) {
                    totalPrice += movie.Budget;
                }
                favorites.Total = totalPrice;
            }
            return favorites;
        }

        public void removeFavorite(long userId, long favoriteId) {
            List<Movie> movieList = _userFavorites[userId].MovieList;
            for (int i = 0; i < movieList.Count; i++) {
                if (movieList[i].Id == favoriteId) {
                    movieList.RemoveAt(i);
                }
            }
        }
    }
}
