﻿using System;
using System.Collections.Generic;
using com.cognizant.movie.model;
using com.cognizant.movie.util;

namespace com.cognizant.movie.dao {
    interface IMovieDao {
        List<Movie> getMovieListAdmin();
        List<Movie> getMovieListCustomer();
        void modifyMovie(Movie movie);
        Movie getMovie(long movieId);
    }
}
