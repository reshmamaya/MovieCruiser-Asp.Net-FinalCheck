﻿using System;
using System.Collections.Generic;
using com.cognizant.movie.model;
using com.cognizant.movie.util;

namespace com.cognizant.movie.dao { 
    interface IFavoritesDao {
        void addFavorite(long userId, long favoriteId);
        Favorites getAllFavorites(long userId);
        void removeFavorite(long userId, long favoriteId);
    }
}
