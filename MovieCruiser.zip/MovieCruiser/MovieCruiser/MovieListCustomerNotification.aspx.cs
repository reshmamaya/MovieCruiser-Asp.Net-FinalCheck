﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.movie.dao;
public partial class _Default : System.Web.UI.Page{

    protected void Page_Load(object sender, EventArgs e){
        if (!IsPostBack){
            lblMessage.Text = "";
            DisplayMoviesCustomers();
        }
    }

    protected void GridMovieAddbuttonClick(object sender, GridViewCommandEventArgs e){
        int gridviewrowindex = int.Parse(e.CommandArgument.ToString());
        FavoritesDaoCollectionImpl favoritesDao = new FavoritesDaoCollectionImpl();
        string movieId = gridMovie.Rows[gridviewrowindex].Cells[0].Text;
        favoritesDao.addFavorite(1, long.Parse(movieId));
        lblMessage.Text = "Movie added to the Favorites Successfully";
    }

    protected void GridMovieRowDataBound(object sender, GridViewRowEventArgs e){
        if (e.Row.Cells[3].Text == "True"){
            e.Row.Cells[3].Text = "Yes";
        }
        if (e.Row.Cells[3].Text == "False"){
            e.Row.Cells[3].Text = "No";
        }
        if (e.Row.Cells[6].Text == "True"){
            e.Row.Cells[6].Text = "Yes";
        }
        if (e.Row.Cells[6].Text == "False"){
            e.Row.Cells[6].Text = "No";
        }

    }

    protected void DisplayMoviesCustomers(){
        MovieDaoCollectionImpl movieDao = new MovieDaoCollectionImpl();
        List<com.cognizant.movie.model.Movie> movieList = movieDao.getMovieListCustomer();
        gridMovie.DataSource = movieList;
        gridMovie.DataBind();
    }

}