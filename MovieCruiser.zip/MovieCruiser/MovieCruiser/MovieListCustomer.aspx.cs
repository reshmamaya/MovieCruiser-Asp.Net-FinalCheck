﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.movie.dao;
using com.cognizant.movie.model;

public partial class _Default : System.Web.UI.Page{

    protected void Page_Load(object sender, EventArgs e){

        if (!IsPostBack){          
            DisplayMoviesCustomers();
        }
    }

    protected void GridMovieAddbuttonClick(object sender, GridViewCommandEventArgs e){
        int gridViewRowIndex = int.Parse(e.CommandArgument.ToString());
        FavoritesDaoCollectionImpl favoritesDao = new FavoritesDaoCollectionImpl();
        string movieId = gridMovie.Rows[gridViewRowIndex].Cells[0].Text;
        Response.Redirect("MovieListCustomerNotification.aspx?movieId=" + movieId);    
    }


    protected void DisplayMoviesCustomers(){
        MovieDaoCollectionImpl movieDao = new MovieDaoCollectionImpl();
        List<Movie> movieList = movieDao.getMovieListCustomer();        
        gridMovie.DataSource = movieList;
        gridMovie.DataBind();
    }


    protected void GridMovieRowDataBound(object sender, GridViewRowEventArgs e){
        if (e.Row.Cells[3].Text == "True"){
            e.Row.Cells[3].Text = "Yes";
        }
        if (e.Row.Cells[3].Text == "False"){
            e.Row.Cells[3].Text = "No";
        }
        if (e.Row.Cells[6].Text == "True"){
            e.Row.Cells[6].Text = "Yes";
        }
        if (e.Row.Cells[6].Text == "False"){
            e.Row.Cells[6].Text = "No";
        }        
    }
      
}